﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PassCheck;
using System.Threading;

namespace testClass
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("开始");
            int start = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("结束");
            int end = Convert.ToInt16(Console.ReadLine());
            for (int i = start; i <= end; i++)
            {
                string loginid = "";
                if (i < 100)
                {
                    loginid = "test" + i.ToString().PadLeft(2, '0');
                }
                else
                {
                    loginid = "test" + i.ToString().PadLeft(3, '0');
                }
                LoginObj obj = new LoginObj();
                obj.LoginId = loginid;
                obj.PassWoid = "test24";
                Thread task = new Thread(new ParameterizedThreadStart(runTask));
                Thread.Sleep(80);
                task.Start(obj);
            }

        }


        private static void runTask(Object loginObj)
        {
            LoginObj obj = (LoginObj)loginObj;
            string LoginID = obj.LoginId;
            string PassWord = obj.PassWoid;
            //不要每次调用都创建PassStationCheck对象，只需要创建一次
            PassStationCheck passcheck = new PassStationCheck(LoginID, PassWord);
            for (int i = 0; i < 1000000000; i++)
            {
                string cre = "";
                System.Threading.Thread.Sleep(200);

                //高频连续调用使用函数PassStationCheckForManyTime
                //低频率调用使用函数PassStationCheckForOneTime
                cre = passcheck.PassStationCheckForManyTime("CVM2602FDSCJ000190", "1", "ZPZYQCZ-CQ-21", "EQ_20200818003");
                if (cre.Contains("过站成功"))
                {
                    //成功
                    Console.WriteLine(LoginID + ":" + i + "成功");
                }
                else if (cre.Contains("过站失败"))
                {
                    //失败
                    Console.WriteLine(LoginID + ":" + i + "失败");
                }
                else
                {
                    //异常
                    Console.WriteLine(LoginID + ":" + i + "异常");
                }

                Console.WriteLine(LoginID + ":" + i + "返回值" + cre);
            }
            Console.ReadKey();

        }

    }

    class LoginObj
    {
        string loginId;
        string passWoid;

        public string LoginId
        {
            get
            {
                return loginId;
            }

            set
            {
                loginId = value;
            }
        }

        public string PassWoid
        {
            get
            {
                return passWoid;
            }

            set
            {
                passWoid = value;
            }
        }
    }
}
